package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edtWeight, edtHeightFt, edtHeightIn;
        TextView txtResult;
        Button btnCalculator;
        LinearLayout llMain;

        edtWeight = findViewById(R.id.edtWeight);
        edtHeightFt = findViewById(R.id.edtHeightFt);
        edtHeightIn = findViewById(R.id.edtHeightIn);
        txtResult = findViewById(R.id.txtResult);
        btnCalculator = findViewById(R.id.btnCalculate);
         llMain = findViewById(R.id.llMain);

        btnCalculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //We can see that we have used toString, because getText is editable, which can be see in option, when we select it from suggestion. So, if there is editable option, then we cannot directly use getText, first we have to convert to toString, then to getText.
                int wt = Integer.parseInt(edtWeight.getText().toString());
                int ft = Integer.parseInt(edtHeightFt.getText().toString());
                int in = Integer.parseInt(edtHeightIn.getText().toString());

                int totalIn = ft*12+in;

                double totalCm = totalIn*2.53;

                double totalM = totalCm/100;

                double bmi = wt/(totalM*totalM);


                if(bmi<18.5){
                    txtResult.setText("You are UnderWeight");
                    llMain.setBackgroundColor(getResources().getColor(R.color.uw));
                }
                else if(bmi>=18.5 && bmi<=24.9){
                    txtResult.setText("You are NormalWeight");
                    llMain.setBackgroundColor(getResources().getColor(R.color.nw));
                } 
                else if(25<=bmi && bmi<=29.9){
                    txtResult.setText("You are OverWeight");
                    llMain.setBackgroundColor(getResources().getColor(R.color.ow));
                }
                else if(bmi<=34.9 && bmi>=30){
                    txtResult.setText("You are Obese(Class 1)");
                    llMain.setBackgroundColor(getResources().getColor(R.color.ob1));
                }
                else if(bmi>=35 && bmi<=39.9){
                    txtResult.setText("You are Obese(Class 2)");
                    llMain.setBackgroundColor(getResources().getColor(R.color.ob2));
                }
                else{
                    txtResult.setText("You are Obese(Class 3)");
                    llMain.setBackgroundColor(getResources().getColor(R.color.ob3));
                }

            }
        });
    }
}